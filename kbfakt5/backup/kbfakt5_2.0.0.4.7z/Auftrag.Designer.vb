<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Auftrag
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Auftrag))
        Me.btnClose = New System.Windows.Forms.Button
        Me.txtAuftragNummer = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.AnredenListBox = New System.Windows.Forms.ComboBox
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip
        Me.Status = New System.Windows.Forms.ToolStripStatusLabel
        Me.DataChangedStatus = New System.Windows.Forms.ToolStripStatusLabel
        Me.txtXKundenNr = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.txtXAN1 = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.txtXName1 = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.txtXName2 = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.txtXST = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.txtXPL = New System.Windows.Forms.TextBox
        Me.txtXOT = New System.Windows.Forms.TextBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.txtXTel = New System.Windows.Forms.TextBox
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.chkGedruckt = New System.Windows.Forms.CheckBox
        Me.Label12 = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        Me.FGSTLLNR = New System.Windows.Forms.TextBox
        Me.txtXKZ = New System.Windows.Forms.TextBox
        Me.Label17 = New System.Windows.Forms.Label
        Me.Label18 = New System.Windows.Forms.Label
        Me.TUEV = New System.Windows.Forms.TextBox
        Me.txtSchreiber = New System.Windows.Forms.TextBox
        Me.Label19 = New System.Windows.Forms.Label
        Me.Label20 = New System.Windows.Forms.Label
        Me.Label21 = New System.Windows.Forms.Label
        Me.Label22 = New System.Windows.Forms.Label
        Me.Label23 = New System.Windows.Forms.Label
        Me.Label24 = New System.Windows.Forms.Label
        Me.Label25 = New System.Windows.Forms.Label
        Me.txtXSCHMIER = New System.Windows.Forms.TextBox
        Me.txtXKMSTAND = New System.Windows.Forms.TextBox
        Me.txtXTYP = New System.Windows.Forms.TextBox
        Me.txtXLOHN = New System.Windows.Forms.TextBox
        Me.txtMwStSatz = New System.Windows.Forms.TextBox
        Me.txtXSONDER = New System.Windows.Forms.TextBox
        Me.txtXNetto = New System.Windows.Forms.TextBox
        Me.txtMwStBetrag = New System.Windows.Forms.TextBox
        Me.txtGesamtbetrag = New System.Windows.Forms.TextBox
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.txtDatum = New System.Windows.Forms.DateTimePicker
        Me.txtWerkdatum = New System.Windows.Forms.DateTimePicker
        Me.btnAuftragSuchen = New System.Windows.Forms.Button
        Me.btnKundeSuchen = New System.Windows.Forms.Button
        Me.btnFahrzeugSuchen = New System.Windows.Forms.Button
        Me.btnNeuerAuftrag = New System.Windows.Forms.Button
        Me.btnAbbrechen = New System.Windows.Forms.Button
        Me.btnSpeichern = New System.Windows.Forms.Button
        Me.btnDrucken = New System.Windows.Forms.Button
        Me.chkIsNeuerAuftrag = New System.Windows.Forms.CheckBox
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.btnAdd = New System.Windows.Forms.Button
        Me.btnRemove = New System.Windows.Forms.Button
        Me.btnKundeFREI = New System.Windows.Forms.Button
        Me.txtASU = New System.Windows.Forms.TextBox
        Me.txtSicher = New System.Windows.Forms.TextBox
        Me.btn_Up = New System.Windows.Forms.Button
        Me.btn_down = New System.Windows.Forms.Button
        Me.btnFahrzeugFREI = New System.Windows.Forms.Button
        Me.txtXZULASS = New System.Windows.Forms.TextBox
        Me.btnArtikelFreiEingabe = New System.Windows.Forms.Button
        Me.btnRichtwerte = New System.Windows.Forms.Button
        Me.DataGridView1 = New kbfakt5.DataGridViewEnter1
        Me.btnRichtwertEingabe = New System.Windows.Forms.Button
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.idAuftrag = New System.Windows.Forms.Label
        Me.idFahrzeug = New System.Windows.Forms.Label
        Me.btnAufSuchen2 = New System.Windows.Forms.Button
        Me.btnAuftragNeu2 = New System.Windows.Forms.Button
        Me.btnKundeFrei2 = New System.Windows.Forms.Button
        Me.btnKundeSuchen2 = New System.Windows.Forms.Button
        Me.btnBuchenTest = New System.Windows.Forms.Button
        Me.Label8 = New System.Windows.Forms.Label
        Me.btnAuftragDrucken = New System.Windows.Forms.Button
        Me.btnKVdrucken = New System.Windows.Forms.Button
        Me.btnLieferscheinDrucken = New System.Windows.Forms.Button
        Me.PanelArtikel = New System.Windows.Forms.Panel
        Me.Label14 = New System.Windows.Forms.Label
        Me.btnArtikelHilfe = New System.Windows.Forms.Button
        Me.StatusStrip1.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelArtikel.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(698, 89)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(84, 29)
        Me.btnClose.TabIndex = 0
        Me.btnClose.Text = "Schliessen"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'txtAuftragNummer
        '
        Me.txtAuftragNummer.Location = New System.Drawing.Point(66, 8)
        Me.txtAuftragNummer.Name = "txtAuftragNummer"
        Me.txtAuftragNummer.Size = New System.Drawing.Size(53, 20)
        Me.txtAuftragNummer.TabIndex = 1
        Me.ToolTip1.SetToolTip(Me.txtAuftragNummer, "F3 = Suchen, F4 = Neu, Enter = Abrufen")
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 11)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(58, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Auftragsnr:"
        '
        'AnredenListBox
        '
        Me.AnredenListBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.AnredenListBox.Enabled = False
        Me.AnredenListBox.FormattingEnabled = True
        Me.AnredenListBox.Location = New System.Drawing.Point(66, 60)
        Me.AnredenListBox.Name = "AnredenListBox"
        Me.AnredenListBox.Size = New System.Drawing.Size(108, 21)
        Me.AnredenListBox.TabIndex = 4
        Me.AnredenListBox.Tag = """kunde"""
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Status, Me.DataChangedStatus})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 606)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(794, 22)
        Me.StatusStrip1.TabIndex = 5
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'Status
        '
        Me.Status.Name = "Status"
        Me.Status.Size = New System.Drawing.Size(762, 17)
        Me.Status.Spring = True
        Me.Status.Text = "Status"
        '
        'DataChangedStatus
        '
        Me.DataChangedStatus.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
                    Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
                    Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.DataChangedStatus.BorderStyle = System.Windows.Forms.Border3DStyle.RaisedOuter
        Me.DataChangedStatus.Name = "DataChangedStatus"
        Me.DataChangedStatus.Size = New System.Drawing.Size(17, 17)
        Me.DataChangedStatus.Text = "X"
        Me.DataChangedStatus.ToolTipText = "Daten ge�ndert?"
        '
        'txtXKundenNr
        '
        Me.txtXKundenNr.Enabled = False
        Me.txtXKundenNr.Location = New System.Drawing.Point(66, 34)
        Me.txtXKundenNr.Name = "txtXKundenNr"
        Me.txtXKundenNr.Size = New System.Drawing.Size(53, 20)
        Me.txtXKundenNr.TabIndex = 6
        Me.txtXKundenNr.Tag = """kunde"""
        Me.ToolTip1.SetToolTip(Me.txtXKundenNr, "F3 = Suchen, Enter = Abrufen")
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(6, 37)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(56, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Kundennr:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(6, 63)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(44, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Anrede:"
        '
        'txtXAN1
        '
        Me.txtXAN1.Enabled = False
        Me.txtXAN1.Location = New System.Drawing.Point(180, 60)
        Me.txtXAN1.Name = "txtXAN1"
        Me.txtXAN1.Size = New System.Drawing.Size(23, 20)
        Me.txtXAN1.TabIndex = 6
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(6, 89)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(44, 13)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "Name1:"
        '
        'txtXName1
        '
        Me.txtXName1.Enabled = False
        Me.txtXName1.Location = New System.Drawing.Point(66, 86)
        Me.txtXName1.Name = "txtXName1"
        Me.txtXName1.Size = New System.Drawing.Size(137, 20)
        Me.txtXName1.TabIndex = 6
        Me.txtXName1.Tag = """kunde"""
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(6, 115)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(44, 13)
        Me.Label5.TabIndex = 2
        Me.Label5.Text = "Name2:"
        '
        'txtXName2
        '
        Me.txtXName2.Enabled = False
        Me.txtXName2.Location = New System.Drawing.Point(66, 112)
        Me.txtXName2.Name = "txtXName2"
        Me.txtXName2.Size = New System.Drawing.Size(137, 20)
        Me.txtXName2.TabIndex = 6
        Me.txtXName2.Tag = """kunde"""
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(6, 141)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(45, 13)
        Me.Label6.TabIndex = 2
        Me.Label6.Text = "Strasse:"
        '
        'txtXST
        '
        Me.txtXST.Enabled = False
        Me.txtXST.Location = New System.Drawing.Point(66, 138)
        Me.txtXST.Name = "txtXST"
        Me.txtXST.Size = New System.Drawing.Size(137, 20)
        Me.txtXST.TabIndex = 6
        Me.txtXST.Tag = """kunde"""
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(6, 167)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(47, 13)
        Me.Label7.TabIndex = 2
        Me.Label7.Text = "Plz - Ort:"
        '
        'txtXPL
        '
        Me.txtXPL.Enabled = False
        Me.txtXPL.Location = New System.Drawing.Point(66, 164)
        Me.txtXPL.Name = "txtXPL"
        Me.txtXPL.Size = New System.Drawing.Size(42, 20)
        Me.txtXPL.TabIndex = 6
        Me.txtXPL.Tag = """kunde"""
        '
        'txtXOT
        '
        Me.txtXOT.Enabled = False
        Me.txtXOT.Location = New System.Drawing.Point(114, 164)
        Me.txtXOT.Name = "txtXOT"
        Me.txtXOT.Size = New System.Drawing.Size(89, 20)
        Me.txtXOT.TabIndex = 6
        Me.txtXOT.Tag = """kunde"""
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(6, 193)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(28, 13)
        Me.Label9.TabIndex = 2
        Me.Label9.Text = "Tel.:"
        '
        'txtXTel
        '
        Me.txtXTel.Enabled = False
        Me.txtXTel.Location = New System.Drawing.Point(66, 190)
        Me.txtXTel.Name = "txtXTel"
        Me.txtXTel.Size = New System.Drawing.Size(137, 20)
        Me.txtXTel.TabIndex = 6
        Me.txtXTel.Tag = """kunde"""
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(614, 41)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(78, 13)
        Me.Label10.TabIndex = 2
        Me.Label10.Text = "Auftragsdatum:"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(614, 66)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(65, 13)
        Me.Label11.TabIndex = 2
        Me.Label11.Text = "Werkdatum:"
        '
        'chkGedruckt
        '
        Me.chkGedruckt.AutoSize = True
        Me.chkGedruckt.Location = New System.Drawing.Point(713, 14)
        Me.chkGedruckt.Name = "chkGedruckt"
        Me.chkGedruckt.Size = New System.Drawing.Size(68, 17)
        Me.chkGedruckt.TabIndex = 7
        Me.chkGedruckt.Tag = "debug"
        Me.chkGedruckt.Text = "gedruckt"
        Me.chkGedruckt.UseVisualStyleBackColor = True
        '
        'Label12
        '
        Me.Label12.Location = New System.Drawing.Point(331, 37)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(76, 13)
        Me.Label12.TabIndex = 2
        Me.Label12.Text = "Fahrgestell-Nr.:"
        '
        'Label13
        '
        Me.Label13.Location = New System.Drawing.Point(331, 64)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(72, 13)
        Me.Label13.TabIndex = 2
        Me.Label13.Text = "Kennzeichen:"
        '
        'FGSTLLNR
        '
        Me.FGSTLLNR.Enabled = False
        Me.FGSTLLNR.Location = New System.Drawing.Point(413, 34)
        Me.FGSTLLNR.Name = "FGSTLLNR"
        Me.FGSTLLNR.Size = New System.Drawing.Size(137, 20)
        Me.FGSTLLNR.TabIndex = 6
        Me.FGSTLLNR.Tag = """fahrzeug"""
        Me.ToolTip1.SetToolTip(Me.FGSTLLNR, "F3 = Suchen, Enter = Abrufen")
        '
        'txtXKZ
        '
        Me.txtXKZ.Location = New System.Drawing.Point(413, 61)
        Me.txtXKZ.Name = "txtXKZ"
        Me.txtXKZ.Size = New System.Drawing.Size(108, 20)
        Me.txtXKZ.TabIndex = 6
        Me.txtXKZ.Tag = """fahrzeug"""
        Me.ToolTip1.SetToolTip(Me.txtXKZ, "Kennzeichen, F3 = Suchen, Enter = Abrufen")
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(331, 167)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(63, 13)
        Me.Label17.TabIndex = 2
        Me.Label17.Text = "T�V - ASU:"
        '
        'Label18
        '
        Me.Label18.Location = New System.Drawing.Point(317, 193)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(90, 13)
        Me.Label18.TabIndex = 2
        Me.Label18.Text = "Schrei./Sicher.:"
        '
        'TUEV
        '
        Me.TUEV.Location = New System.Drawing.Point(413, 164)
        Me.TUEV.Name = "TUEV"
        Me.TUEV.Size = New System.Drawing.Size(67, 20)
        Me.TUEV.TabIndex = 6
        Me.TUEV.Tag = """fahrzeugVars"""
        Me.ToolTip1.SetToolTip(Me.TUEV, "N�chster T�V Termin")
        '
        'txtSchreiber
        '
        Me.txtSchreiber.Location = New System.Drawing.Point(413, 190)
        Me.txtSchreiber.Name = "txtSchreiber"
        Me.txtSchreiber.Size = New System.Drawing.Size(67, 20)
        Me.txtSchreiber.TabIndex = 6
        Me.txtSchreiber.Tag = """fahrzeugVars"""
        Me.ToolTip1.SetToolTip(Me.txtSchreiber, "N�chste Fahrtenschreiberpr�fung")
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(11, 530)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(72, 13)
        Me.Label19.TabIndex = 2
        Me.Label19.Text = "Schmiermittel:"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(11, 556)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(34, 13)
        Me.Label20.TabIndex = 2
        Me.Label20.Text = "Lohn:"
        '
        'Label21
        '
        Me.Label21.Location = New System.Drawing.Point(331, 89)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(66, 13)
        Me.Label21.TabIndex = 2
        Me.Label21.Text = "KM-Stand:"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(331, 140)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(28, 13)
        Me.Label22.TabIndex = 2
        Me.Label22.Text = "Typ:"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(11, 582)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(44, 13)
        Me.Label23.TabIndex = 2
        Me.Label23.Text = "Sonder:"
        '
        'Label24
        '
        Me.Label24.Location = New System.Drawing.Point(331, 115)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(56, 13)
        Me.Label24.TabIndex = 2
        Me.Label24.Text = "Zulassung:"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(623, 552)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(34, 13)
        Me.Label25.TabIndex = 2
        Me.Label25.Text = "MwSt"
        '
        'txtXSCHMIER
        '
        Me.txtXSCHMIER.Enabled = False
        Me.txtXSCHMIER.Location = New System.Drawing.Point(103, 527)
        Me.txtXSCHMIER.Name = "txtXSCHMIER"
        Me.txtXSCHMIER.Size = New System.Drawing.Size(76, 20)
        Me.txtXSCHMIER.TabIndex = 6
        Me.txtXSCHMIER.Tag = ""
        Me.txtXSCHMIER.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtXKMSTAND
        '
        Me.txtXKMSTAND.Location = New System.Drawing.Point(413, 86)
        Me.txtXKMSTAND.Name = "txtXKMSTAND"
        Me.txtXKMSTAND.Size = New System.Drawing.Size(137, 20)
        Me.txtXKMSTAND.TabIndex = 6
        Me.txtXKMSTAND.Tag = """fahrzeugVars"""
        Me.ToolTip1.SetToolTip(Me.txtXKMSTAND, "Kilometerstand")
        '
        'txtXTYP
        '
        Me.txtXTYP.Enabled = False
        Me.txtXTYP.Location = New System.Drawing.Point(413, 137)
        Me.txtXTYP.Name = "txtXTYP"
        Me.txtXTYP.Size = New System.Drawing.Size(137, 20)
        Me.txtXTYP.TabIndex = 6
        Me.txtXTYP.Tag = """fahrzeug"""
        Me.ToolTip1.SetToolTip(Me.txtXTYP, "Fahrzeugtyp")
        '
        'txtXLOHN
        '
        Me.txtXLOHN.Enabled = False
        Me.txtXLOHN.Location = New System.Drawing.Point(103, 553)
        Me.txtXLOHN.Name = "txtXLOHN"
        Me.txtXLOHN.Size = New System.Drawing.Size(76, 20)
        Me.txtXLOHN.TabIndex = 6
        Me.txtXLOHN.Tag = ""
        Me.txtXLOHN.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtMwStSatz
        '
        Me.txtMwStSatz.Enabled = False
        Me.txtMwStSatz.Location = New System.Drawing.Point(663, 549)
        Me.txtMwStSatz.Name = "txtMwStSatz"
        Me.txtMwStSatz.Size = New System.Drawing.Size(36, 20)
        Me.txtMwStSatz.TabIndex = 6
        Me.txtMwStSatz.Tag = """auftrag"""
        Me.txtMwStSatz.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtXSONDER
        '
        Me.txtXSONDER.Enabled = False
        Me.txtXSONDER.Location = New System.Drawing.Point(103, 579)
        Me.txtXSONDER.Name = "txtXSONDER"
        Me.txtXSONDER.Size = New System.Drawing.Size(76, 20)
        Me.txtXSONDER.TabIndex = 6
        Me.txtXSONDER.Tag = ""
        Me.txtXSONDER.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtXNetto
        '
        Me.txtXNetto.Enabled = False
        Me.txtXNetto.Location = New System.Drawing.Point(705, 523)
        Me.txtXNetto.Name = "txtXNetto"
        Me.txtXNetto.Size = New System.Drawing.Size(76, 20)
        Me.txtXNetto.TabIndex = 9
        Me.txtXNetto.Tag = ""
        Me.txtXNetto.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtMwStBetrag
        '
        Me.txtMwStBetrag.Enabled = False
        Me.txtMwStBetrag.Location = New System.Drawing.Point(705, 549)
        Me.txtMwStBetrag.Name = "txtMwStBetrag"
        Me.txtMwStBetrag.Size = New System.Drawing.Size(76, 20)
        Me.txtMwStBetrag.TabIndex = 9
        Me.txtMwStBetrag.Tag = ""
        Me.txtMwStBetrag.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtGesamtbetrag
        '
        Me.txtGesamtbetrag.Enabled = False
        Me.txtGesamtbetrag.Location = New System.Drawing.Point(705, 575)
        Me.txtGesamtbetrag.Name = "txtGesamtbetrag"
        Me.txtGesamtbetrag.Size = New System.Drawing.Size(76, 20)
        Me.txtGesamtbetrag.TabIndex = 9
        Me.txtGesamtbetrag.Tag = ""
        Me.txtGesamtbetrag.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox1
        '
        Me.TextBox1.Enabled = False
        Me.TextBox1.Location = New System.Drawing.Point(647, 523)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ReadOnly = True
        Me.TextBox1.Size = New System.Drawing.Size(52, 20)
        Me.TextBox1.TabIndex = 10
        Me.TextBox1.Tag = """debug"""
        Me.TextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtDatum
        '
        Me.txtDatum.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.txtDatum.Location = New System.Drawing.Point(698, 38)
        Me.txtDatum.Name = "txtDatum"
        Me.txtDatum.Size = New System.Drawing.Size(84, 20)
        Me.txtDatum.TabIndex = 11
        Me.txtDatum.Tag = """auftrag"""
        '
        'txtWerkdatum
        '
        Me.txtWerkdatum.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.txtWerkdatum.Location = New System.Drawing.Point(698, 62)
        Me.txtWerkdatum.Name = "txtWerkdatum"
        Me.txtWerkdatum.Size = New System.Drawing.Size(84, 20)
        Me.txtWerkdatum.TabIndex = 11
        Me.txtWerkdatum.Tag = """auftrag"""
        '
        'btnAuftragSuchen
        '
        Me.btnAuftragSuchen.Image = Global.kbfakt5.My.Resources.Resources.search2small
        Me.btnAuftragSuchen.Location = New System.Drawing.Point(245, 7)
        Me.btnAuftragSuchen.Name = "btnAuftragSuchen"
        Me.btnAuftragSuchen.Size = New System.Drawing.Size(23, 20)
        Me.btnAuftragSuchen.TabIndex = 12
        Me.btnAuftragSuchen.UseVisualStyleBackColor = True
        '
        'btnKundeSuchen
        '
        Me.btnKundeSuchen.Image = Global.kbfakt5.My.Resources.Resources.search2small
        Me.btnKundeSuchen.Location = New System.Drawing.Point(245, 33)
        Me.btnKundeSuchen.Name = "btnKundeSuchen"
        Me.btnKundeSuchen.Size = New System.Drawing.Size(23, 21)
        Me.btnKundeSuchen.TabIndex = 12
        Me.btnKundeSuchen.Tag = """kunde"""
        Me.btnKundeSuchen.UseVisualStyleBackColor = True
        '
        'btnFahrzeugSuchen
        '
        Me.btnFahrzeugSuchen.Image = Global.kbfakt5.My.Resources.Resources.search2small
        Me.btnFahrzeugSuchen.Location = New System.Drawing.Point(527, 61)
        Me.btnFahrzeugSuchen.Name = "btnFahrzeugSuchen"
        Me.btnFahrzeugSuchen.Size = New System.Drawing.Size(23, 20)
        Me.btnFahrzeugSuchen.TabIndex = 12
        Me.btnFahrzeugSuchen.Tag = """fahrzeugVars"""
        Me.ToolTip1.SetToolTip(Me.btnFahrzeugSuchen, "Fahrzeug suchen")
        Me.btnFahrzeugSuchen.UseVisualStyleBackColor = True
        '
        'btnNeuerAuftrag
        '
        Me.btnNeuerAuftrag.BackgroundImage = Global.kbfakt5.My.Resources.Resources.plus
        Me.btnNeuerAuftrag.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnNeuerAuftrag.Location = New System.Drawing.Point(271, 7)
        Me.btnNeuerAuftrag.Name = "btnNeuerAuftrag"
        Me.btnNeuerAuftrag.Size = New System.Drawing.Size(23, 20)
        Me.btnNeuerAuftrag.TabIndex = 12
        Me.btnNeuerAuftrag.UseVisualStyleBackColor = True
        '
        'btnAbbrechen
        '
        Me.btnAbbrechen.Enabled = False
        Me.btnAbbrechen.Location = New System.Drawing.Point(608, 124)
        Me.btnAbbrechen.Name = "btnAbbrechen"
        Me.btnAbbrechen.Size = New System.Drawing.Size(84, 29)
        Me.btnAbbrechen.TabIndex = 0
        Me.btnAbbrechen.Text = "Abbrechen"
        Me.btnAbbrechen.UseVisualStyleBackColor = True
        '
        'btnSpeichern
        '
        Me.btnSpeichern.Enabled = False
        Me.btnSpeichern.Location = New System.Drawing.Point(698, 124)
        Me.btnSpeichern.Name = "btnSpeichern"
        Me.btnSpeichern.Size = New System.Drawing.Size(84, 29)
        Me.btnSpeichern.TabIndex = 0
        Me.btnSpeichern.Text = "Speichern"
        Me.btnSpeichern.UseVisualStyleBackColor = True
        '
        'btnDrucken
        '
        Me.btnDrucken.Enabled = False
        Me.btnDrucken.Location = New System.Drawing.Point(608, 159)
        Me.btnDrucken.Name = "btnDrucken"
        Me.btnDrucken.Size = New System.Drawing.Size(174, 29)
        Me.btnDrucken.TabIndex = 0
        Me.btnDrucken.Text = "Rechnung drucken"
        Me.btnDrucken.UseVisualStyleBackColor = True
        '
        'chkIsNeuerAuftrag
        '
        Me.chkIsNeuerAuftrag.AutoSize = True
        Me.chkIsNeuerAuftrag.Enabled = False
        Me.chkIsNeuerAuftrag.Location = New System.Drawing.Point(334, 7)
        Me.chkIsNeuerAuftrag.Name = "chkIsNeuerAuftrag"
        Me.chkIsNeuerAuftrag.Size = New System.Drawing.Size(49, 17)
        Me.chkIsNeuerAuftrag.TabIndex = 13
        Me.chkIsNeuerAuftrag.Tag = """debug"""
        Me.chkIsNeuerAuftrag.Text = "NEU"
        Me.chkIsNeuerAuftrag.UseVisualStyleBackColor = True
        '
        'btnAdd
        '
        Me.btnAdd.BackgroundImage = Global.kbfakt5.My.Resources.Resources.plus
        Me.btnAdd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnAdd.Location = New System.Drawing.Point(58, 7)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(22, 20)
        Me.btnAdd.TabIndex = 16
        Me.btnAdd.Tag = """auftrag"""
        Me.ToolTip1.SetToolTip(Me.btnAdd, "Artikel hinzuf�gen")
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'btnRemove
        '
        Me.btnRemove.BackgroundImage = Global.kbfakt5.My.Resources.Resources.minus
        Me.btnRemove.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnRemove.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRemove.Location = New System.Drawing.Point(86, 7)
        Me.btnRemove.Name = "btnRemove"
        Me.btnRemove.Size = New System.Drawing.Size(22, 20)
        Me.btnRemove.TabIndex = 16
        Me.btnRemove.Tag = """auftrag"""
        Me.ToolTip1.SetToolTip(Me.btnRemove, "Artikelzeile entfernen")
        Me.btnRemove.UseVisualStyleBackColor = True
        '
        'btnKundeFREI
        '
        Me.btnKundeFREI.BackgroundImage = Global.kbfakt5.My.Resources.Resources.free
        Me.btnKundeFREI.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btnKundeFREI.Location = New System.Drawing.Point(272, 32)
        Me.btnKundeFREI.Name = "btnKundeFREI"
        Me.btnKundeFREI.Size = New System.Drawing.Size(22, 23)
        Me.btnKundeFREI.TabIndex = 18
        Me.btnKundeFREI.Text = "?"
        Me.ToolTip1.SetToolTip(Me.btnKundeFREI, "Freie Eingabe")
        Me.btnKundeFREI.UseVisualStyleBackColor = True
        '
        'txtASU
        '
        Me.txtASU.Location = New System.Drawing.Point(486, 164)
        Me.txtASU.Name = "txtASU"
        Me.txtASU.Size = New System.Drawing.Size(67, 20)
        Me.txtASU.TabIndex = 6
        Me.txtASU.Tag = """fahrzeugVars"""
        Me.ToolTip1.SetToolTip(Me.txtASU, "N�chster ASU Termin")
        '
        'txtSicher
        '
        Me.txtSicher.Location = New System.Drawing.Point(486, 190)
        Me.txtSicher.Name = "txtSicher"
        Me.txtSicher.Size = New System.Drawing.Size(67, 20)
        Me.txtSicher.TabIndex = 6
        Me.txtSicher.Tag = """fahrzeugVars"""
        Me.ToolTip1.SetToolTip(Me.txtSicher, "N�chste Sicherheitspr�fung")
        '
        'btn_Up
        '
        Me.btn_Up.BackgroundImage = Global.kbfakt5.My.Resources.Resources.up
        Me.btn_Up.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_Up.Location = New System.Drawing.Point(145, 7)
        Me.btn_Up.Name = "btn_Up"
        Me.btn_Up.Size = New System.Drawing.Size(22, 20)
        Me.btn_Up.TabIndex = 17
        Me.btn_Up.Tag = """auftrag"""
        Me.ToolTip1.SetToolTip(Me.btn_Up, "Artikel nach oben verschieben")
        Me.btn_Up.UseVisualStyleBackColor = True
        '
        'btn_down
        '
        Me.btn_down.BackgroundImage = Global.kbfakt5.My.Resources.Resources.down
        Me.btn_down.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_down.Location = New System.Drawing.Point(173, 7)
        Me.btn_down.Name = "btn_down"
        Me.btn_down.Size = New System.Drawing.Size(22, 20)
        Me.btn_down.TabIndex = 17
        Me.btn_down.Tag = """auftrag"""
        Me.ToolTip1.SetToolTip(Me.btn_down, "Artikel nach unten verschieben")
        Me.btn_down.UseVisualStyleBackColor = True
        '
        'btnFahrzeugFREI
        '
        Me.btnFahrzeugFREI.BackgroundImage = Global.kbfakt5.My.Resources.Resources.free
        Me.btnFahrzeugFREI.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btnFahrzeugFREI.Location = New System.Drawing.Point(556, 35)
        Me.btnFahrzeugFREI.Name = "btnFahrzeugFREI"
        Me.btnFahrzeugFREI.Size = New System.Drawing.Size(22, 20)
        Me.btnFahrzeugFREI.TabIndex = 18
        Me.btnFahrzeugFREI.Tag = """fahrzeugVars"""
        Me.btnFahrzeugFREI.Text = "?"
        Me.ToolTip1.SetToolTip(Me.btnFahrzeugFREI, "Freie Fahrzeugeingabe")
        Me.btnFahrzeugFREI.UseVisualStyleBackColor = True
        '
        'txtXZULASS
        '
        Me.txtXZULASS.Enabled = False
        Me.txtXZULASS.Location = New System.Drawing.Point(413, 112)
        Me.txtXZULASS.Name = "txtXZULASS"
        Me.txtXZULASS.Size = New System.Drawing.Size(66, 20)
        Me.txtXZULASS.TabIndex = 19
        Me.ToolTip1.SetToolTip(Me.txtXZULASS, "Datum der ersten Zulassung")
        '
        'btnArtikelFreiEingabe
        '
        Me.btnArtikelFreiEingabe.BackgroundImage = Global.kbfakt5.My.Resources.Resources.free
        Me.btnArtikelFreiEingabe.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnArtikelFreiEingabe.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.btnArtikelFreiEingabe.Location = New System.Drawing.Point(114, 7)
        Me.btnArtikelFreiEingabe.Name = "btnArtikelFreiEingabe"
        Me.btnArtikelFreiEingabe.Size = New System.Drawing.Size(22, 20)
        Me.btnArtikelFreiEingabe.TabIndex = 18
        Me.btnArtikelFreiEingabe.Tag = """auftrag"""
        Me.ToolTip1.SetToolTip(Me.btnArtikelFreiEingabe, "Neue freie Artikeleingabe")
        Me.btnArtikelFreiEingabe.UseVisualStyleBackColor = True
        '
        'btnRichtwerte
        '
        Me.btnRichtwerte.BackgroundImage = CType(resources.GetObject("btnRichtwerte.BackgroundImage"), System.Drawing.Image)
        Me.btnRichtwerte.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnRichtwerte.Location = New System.Drawing.Point(285, 7)
        Me.btnRichtwerte.Name = "btnRichtwerte"
        Me.btnRichtwerte.Size = New System.Drawing.Size(23, 20)
        Me.btnRichtwerte.TabIndex = 24
        Me.btnRichtwerte.Tag = """auftrag"""
        Me.ToolTip1.SetToolTip(Me.btnRichtwerte, "Richtwert anf�gen")
        Me.btnRichtwerte.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnF2
        Me.DataGridView1.Location = New System.Drawing.Point(9, 337)
        Me.DataGridView1.MultiSelect = False
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.DataGridView1.Size = New System.Drawing.Size(772, 183)
        Me.DataGridView1.TabIndex = 8
        Me.DataGridView1.Tag = ""
        Me.ToolTip1.SetToolTip(Me.DataGridView1, "Artikel mit + werden beim Buchen neu angelegt, Artikel mit * sind frei, F3 zum Su" & _
                "chen, 'ZEIT/' plus Kennung erm�glicht die Neuanlage eines Richtwerts, 'ZEIT/' �f" & _
                "fnet den Richtwertauswahldialog")
        '
        'btnRichtwertEingabe
        '
        Me.btnRichtwertEingabe.BackgroundImage = Global.kbfakt5.My.Resources.Resources.free
        Me.btnRichtwertEingabe.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnRichtwertEingabe.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.btnRichtwertEingabe.Location = New System.Drawing.Point(311, 7)
        Me.btnRichtwertEingabe.Name = "btnRichtwertEingabe"
        Me.btnRichtwertEingabe.Size = New System.Drawing.Size(22, 20)
        Me.btnRichtwertEingabe.TabIndex = 18
        Me.btnRichtwertEingabe.Tag = """auftrag"""
        Me.ToolTip1.SetToolTip(Me.btnRichtwertEingabe, "Neuen Richtwert anf�gen")
        Me.btnRichtwertEingabe.UseVisualStyleBackColor = True
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.ContainerControl = Me
        '
        'idAuftrag
        '
        Me.idAuftrag.AutoSize = True
        Me.idAuftrag.Location = New System.Drawing.Point(410, 8)
        Me.idAuftrag.Name = "idAuftrag"
        Me.idAuftrag.Size = New System.Drawing.Size(15, 13)
        Me.idAuftrag.TabIndex = 15
        Me.idAuftrag.Text = "id"
        '
        'idFahrzeug
        '
        Me.idFahrzeug.AutoSize = True
        Me.idFahrzeug.Location = New System.Drawing.Point(486, 115)
        Me.idFahrzeug.Name = "idFahrzeug"
        Me.idFahrzeug.Size = New System.Drawing.Size(15, 13)
        Me.idFahrzeug.TabIndex = 15
        Me.idFahrzeug.Text = "id"
        '
        'btnAufSuchen2
        '
        Me.btnAufSuchen2.Location = New System.Drawing.Point(124, 7)
        Me.btnAufSuchen2.Name = "btnAufSuchen2"
        Me.btnAufSuchen2.Size = New System.Drawing.Size(56, 20)
        Me.btnAufSuchen2.TabIndex = 20
        Me.btnAufSuchen2.Text = "Suchen"
        Me.btnAufSuchen2.UseVisualStyleBackColor = True
        '
        'btnAuftragNeu2
        '
        Me.btnAuftragNeu2.Location = New System.Drawing.Point(186, 7)
        Me.btnAuftragNeu2.Name = "btnAuftragNeu2"
        Me.btnAuftragNeu2.Size = New System.Drawing.Size(53, 20)
        Me.btnAuftragNeu2.TabIndex = 20
        Me.btnAuftragNeu2.Text = "NEU"
        Me.btnAuftragNeu2.UseVisualStyleBackColor = True
        '
        'btnKundeFrei2
        '
        Me.btnKundeFrei2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btnKundeFrei2.Location = New System.Drawing.Point(186, 33)
        Me.btnKundeFrei2.Name = "btnKundeFrei2"
        Me.btnKundeFrei2.Size = New System.Drawing.Size(53, 21)
        Me.btnKundeFrei2.TabIndex = 18
        Me.btnKundeFrei2.Text = "Frei"
        Me.btnKundeFrei2.UseVisualStyleBackColor = True
        '
        'btnKundeSuchen2
        '
        Me.btnKundeSuchen2.Location = New System.Drawing.Point(124, 34)
        Me.btnKundeSuchen2.Name = "btnKundeSuchen2"
        Me.btnKundeSuchen2.Size = New System.Drawing.Size(56, 20)
        Me.btnKundeSuchen2.TabIndex = 21
        Me.btnKundeSuchen2.Text = "Suchen"
        Me.btnKundeSuchen2.UseVisualStyleBackColor = True
        '
        'btnBuchenTest
        '
        Me.btnBuchenTest.Location = New System.Drawing.Point(698, 308)
        Me.btnBuchenTest.Name = "btnBuchenTest"
        Me.btnBuchenTest.Size = New System.Drawing.Size(82, 23)
        Me.btnBuchenTest.TabIndex = 22
        Me.btnBuchenTest.Text = "Buchen(Test)"
        Me.btnBuchenTest.UseVisualStyleBackColor = True
        Me.btnBuchenTest.Visible = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(3, 7)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(39, 13)
        Me.Label8.TabIndex = 23
        Me.Label8.Text = "Artikel:"
        '
        'btnAuftragDrucken
        '
        Me.btnAuftragDrucken.Enabled = False
        Me.btnAuftragDrucken.Location = New System.Drawing.Point(608, 193)
        Me.btnAuftragDrucken.Name = "btnAuftragDrucken"
        Me.btnAuftragDrucken.Size = New System.Drawing.Size(174, 29)
        Me.btnAuftragDrucken.TabIndex = 0
        Me.btnAuftragDrucken.Text = "Auftrag drucken"
        Me.btnAuftragDrucken.UseVisualStyleBackColor = True
        '
        'btnKVdrucken
        '
        Me.btnKVdrucken.Enabled = False
        Me.btnKVdrucken.Location = New System.Drawing.Point(608, 228)
        Me.btnKVdrucken.Name = "btnKVdrucken"
        Me.btnKVdrucken.Size = New System.Drawing.Size(174, 29)
        Me.btnKVdrucken.TabIndex = 0
        Me.btnKVdrucken.Text = "Kostenvoranschlag drucken"
        Me.btnKVdrucken.UseVisualStyleBackColor = True
        '
        'btnLieferscheinDrucken
        '
        Me.btnLieferscheinDrucken.Enabled = False
        Me.btnLieferscheinDrucken.Location = New System.Drawing.Point(608, 263)
        Me.btnLieferscheinDrucken.Name = "btnLieferscheinDrucken"
        Me.btnLieferscheinDrucken.Size = New System.Drawing.Size(174, 29)
        Me.btnLieferscheinDrucken.TabIndex = 0
        Me.btnLieferscheinDrucken.Text = "Lieferschein drucken"
        Me.btnLieferscheinDrucken.UseVisualStyleBackColor = True
        '
        'PanelArtikel
        '
        Me.PanelArtikel.Controls.Add(Me.btnArtikelHilfe)
        Me.PanelArtikel.Controls.Add(Me.btnRichtwerte)
        Me.PanelArtikel.Controls.Add(Me.Label14)
        Me.PanelArtikel.Controls.Add(Me.Label8)
        Me.PanelArtikel.Controls.Add(Me.btnAdd)
        Me.PanelArtikel.Controls.Add(Me.btnRemove)
        Me.PanelArtikel.Controls.Add(Me.btn_Up)
        Me.PanelArtikel.Controls.Add(Me.btn_down)
        Me.PanelArtikel.Controls.Add(Me.btnRichtwertEingabe)
        Me.PanelArtikel.Controls.Add(Me.btnArtikelFreiEingabe)
        Me.PanelArtikel.Location = New System.Drawing.Point(9, 298)
        Me.PanelArtikel.Name = "PanelArtikel"
        Me.PanelArtikel.Size = New System.Drawing.Size(398, 33)
        Me.PanelArtikel.TabIndex = 24
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(220, 7)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(61, 13)
        Me.Label14.TabIndex = 23
        Me.Label14.Text = "Richtwerte:"
        '
        'btnArtikelHilfe
        '
        Me.btnArtikelHilfe.Location = New System.Drawing.Point(373, 7)
        Me.btnArtikelHilfe.Name = "btnArtikelHilfe"
        Me.btnArtikelHilfe.Size = New System.Drawing.Size(20, 19)
        Me.btnArtikelHilfe.TabIndex = 25
        Me.btnArtikelHilfe.Text = "?"
        Me.btnArtikelHilfe.UseVisualStyleBackColor = True
        '
        'Auftrag
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(794, 628)
        Me.ControlBox = False
        Me.Controls.Add(Me.PanelArtikel)
        Me.Controls.Add(Me.btnBuchenTest)
        Me.Controls.Add(Me.btnKundeSuchen2)
        Me.Controls.Add(Me.btnAuftragNeu2)
        Me.Controls.Add(Me.btnAufSuchen2)
        Me.Controls.Add(Me.txtXZULASS)
        Me.Controls.Add(Me.btnFahrzeugFREI)
        Me.Controls.Add(Me.btnKundeFrei2)
        Me.Controls.Add(Me.btnKundeFREI)
        Me.Controls.Add(Me.idFahrzeug)
        Me.Controls.Add(Me.idAuftrag)
        Me.Controls.Add(Me.chkIsNeuerAuftrag)
        Me.Controls.Add(Me.btnFahrzeugSuchen)
        Me.Controls.Add(Me.btnKundeSuchen)
        Me.Controls.Add(Me.btnNeuerAuftrag)
        Me.Controls.Add(Me.btnAuftragSuchen)
        Me.Controls.Add(Me.txtWerkdatum)
        Me.Controls.Add(Me.txtDatum)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.txtGesamtbetrag)
        Me.Controls.Add(Me.txtMwStBetrag)
        Me.Controls.Add(Me.txtXNetto)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.chkGedruckt)
        Me.Controls.Add(Me.txtXOT)
        Me.Controls.Add(Me.txtXPL)
        Me.Controls.Add(Me.txtXSONDER)
        Me.Controls.Add(Me.txtMwStSatz)
        Me.Controls.Add(Me.txtSchreiber)
        Me.Controls.Add(Me.txtXST)
        Me.Controls.Add(Me.txtXLOHN)
        Me.Controls.Add(Me.txtXKZ)
        Me.Controls.Add(Me.txtXTYP)
        Me.Controls.Add(Me.txtSicher)
        Me.Controls.Add(Me.txtASU)
        Me.Controls.Add(Me.TUEV)
        Me.Controls.Add(Me.txtXKMSTAND)
        Me.Controls.Add(Me.txtXName2)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.txtXSCHMIER)
        Me.Controls.Add(Me.Label25)
        Me.Controls.Add(Me.FGSTLLNR)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.txtXName1)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.txtXAN1)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txtXTel)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.txtXKundenNr)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.AnredenListBox)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtAuftragNummer)
        Me.Controls.Add(Me.btnLieferscheinDrucken)
        Me.Controls.Add(Me.btnKVdrucken)
        Me.Controls.Add(Me.btnAuftragDrucken)
        Me.Controls.Add(Me.btnDrucken)
        Me.Controls.Add(Me.btnSpeichern)
        Me.Controls.Add(Me.btnAbbrechen)
        Me.Controls.Add(Me.btnClose)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Auftrag"
        Me.Text = "Auftrag"
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelArtikel.ResumeLayout(False)
        Me.PanelArtikel.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents txtAuftragNummer As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents AnredenListBox As System.Windows.Forms.ComboBox
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents txtXKundenNr As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtXAN1 As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtXName1 As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtXName2 As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtXST As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtXPL As System.Windows.Forms.TextBox
    Friend WithEvents txtXOT As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents txtXTel As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents chkGedruckt As System.Windows.Forms.CheckBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents FGSTLLNR As System.Windows.Forms.TextBox
    Friend WithEvents txtXKZ As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents TUEV As System.Windows.Forms.TextBox
    Friend WithEvents txtSchreiber As System.Windows.Forms.TextBox
    Friend WithEvents DataGridView1 As kbfakt5.DataGridViewEnter1
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents txtXSCHMIER As System.Windows.Forms.TextBox
    Friend WithEvents txtXKMSTAND As System.Windows.Forms.TextBox
    Friend WithEvents txtXTYP As System.Windows.Forms.TextBox
    Friend WithEvents txtXLOHN As System.Windows.Forms.TextBox
    Friend WithEvents txtMwStSatz As System.Windows.Forms.TextBox
    Friend WithEvents txtXSONDER As System.Windows.Forms.TextBox
    Friend WithEvents txtXNetto As System.Windows.Forms.TextBox
    Friend WithEvents txtMwStBetrag As System.Windows.Forms.TextBox
    Friend WithEvents txtGesamtbetrag As System.Windows.Forms.TextBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents txtDatum As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtWerkdatum As System.Windows.Forms.DateTimePicker
    Friend WithEvents btnAuftragSuchen As System.Windows.Forms.Button
    Friend WithEvents btnKundeSuchen As System.Windows.Forms.Button
    Friend WithEvents btnFahrzeugSuchen As System.Windows.Forms.Button
    Friend WithEvents btnNeuerAuftrag As System.Windows.Forms.Button
    Friend WithEvents Status As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents btnAbbrechen As System.Windows.Forms.Button
    Friend WithEvents btnSpeichern As System.Windows.Forms.Button
    Friend WithEvents btnDrucken As System.Windows.Forms.Button
    Friend WithEvents chkIsNeuerAuftrag As System.Windows.Forms.CheckBox
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents ErrorProvider1 As System.Windows.Forms.ErrorProvider
    Friend WithEvents idAuftrag As System.Windows.Forms.Label
    Friend WithEvents idFahrzeug As System.Windows.Forms.Label
    Friend WithEvents txtASU As System.Windows.Forms.TextBox
    Friend WithEvents txtSicher As System.Windows.Forms.TextBox
    Friend WithEvents btnRemove As System.Windows.Forms.Button
    Friend WithEvents btnAdd As System.Windows.Forms.Button
    Friend WithEvents DataChangedStatus As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents btn_down As System.Windows.Forms.Button
    Friend WithEvents btn_Up As System.Windows.Forms.Button
    Friend WithEvents btnKundeFREI As System.Windows.Forms.Button
    Friend WithEvents btnFahrzeugFREI As System.Windows.Forms.Button
    Friend WithEvents txtXZULASS As System.Windows.Forms.TextBox
    Friend WithEvents btnArtikelFreiEingabe As System.Windows.Forms.Button
    Friend WithEvents btnAufSuchen2 As System.Windows.Forms.Button
    Friend WithEvents btnAuftragNeu2 As System.Windows.Forms.Button
    Friend WithEvents btnKundeFrei2 As System.Windows.Forms.Button
    Friend WithEvents btnKundeSuchen2 As System.Windows.Forms.Button
    Friend WithEvents btnBuchenTest As System.Windows.Forms.Button
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents btnAuftragDrucken As System.Windows.Forms.Button
    Friend WithEvents btnKVdrucken As System.Windows.Forms.Button
    Friend WithEvents btnLieferscheinDrucken As System.Windows.Forms.Button
    Friend WithEvents PanelArtikel As System.Windows.Forms.Panel
    Friend WithEvents btnRichtwerte As System.Windows.Forms.Button
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents btnRichtwertEingabe As System.Windows.Forms.Button
    Friend WithEvents btnArtikelHilfe As System.Windows.Forms.Button
End Class
