Public Class PrintAuftragRawSetup
    Public m_TopOffset As Integer = 10
    Public m_LinesPerPage As Integer = 80
    Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
        If CheckDaten() Then
            DialogResult = Windows.Forms.DialogResult.OK
            Me.Close()
        End If
    End Sub
    Function CheckDaten() As Boolean
        Dim top As Integer
        Dim leng As Integer
        Try
            top = CInt(txtTopOffset.Text)
            txtTopOffset.BackColor = Color.White
            m_TopOffset = top
        Catch ex As Exception
            txtTopOffset.BackColor = Color.Pink
            top = -1
        End Try
        Try
            leng = CInt(txtPageLength.Text)
            txtPageLength.BackColor = Color.White
            m_LinesPerPage = leng
        Catch ex As Exception
            txtPageLength.BackColor = Color.Pink
            leng = -1
        End Try
        If leng = -1 Or top = -1 Then
            Return False
        Else
            Return True
        End If
    End Function

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        DialogResult = Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

    Private Sub PrintAuftragRawSetup_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        txtPageLength.Text = m_LinesPerPage.ToString()
        txtTopOffset.Text = m_TopOffset.ToString()
    End Sub
End Class