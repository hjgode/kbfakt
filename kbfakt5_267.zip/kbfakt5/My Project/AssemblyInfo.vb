Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("kbfakt")> 
<Assembly: AssemblyDescription("KFZ Fakturierung")> 
<Assembly: AssemblyCompany("hgo")> 
<Assembly: AssemblyProduct("kbfakt")> 
<Assembly: AssemblyCopyright("Copyright © hjgode 2007/2008")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("08938a2e-bad5-4d72-9aae-e1c0ce872742")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("2.0.2.7")> 
<Assembly: AssemblyFileVersion("2.0.2.7")> 
