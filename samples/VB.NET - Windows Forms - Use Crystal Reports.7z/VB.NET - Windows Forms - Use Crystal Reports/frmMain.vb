Option Strict On
Option Explicit On 

Imports System.Data
Imports System.Data.SqlClient
Imports CrystalDecisions.CrystalReports.Engine

Public Class frmMain
    Inherits System.Windows.Forms.Form

    Protected Const MSDE_SERVER As String = "(local)\VSdotNET"
    'SQLEXPRESS needs a new connect string!
    Protected Const SQL_CONNECTION_STRING As String = _
            "Server=EUDEDUSWSSYS08\SQLEXPRESS;" & _
            "DataBase=Northwind;" & _
            "Integrated Security=SSPI;Connect Timeout=5"

    Protected Const MSDE_CONNECTION_STRING As String = _
        "Server=" & MSDE_SERVER & ";" & _
        "DataBase=Northwind;" & _
        "Integrated Security=SSPI;Connect Timeout=5"

    Private ConnectionString As String = SQL_CONNECTION_STRING
    Private HasConnected As Boolean = False
    Private ServerName As String = "EUDEDUSWSSYS08\SQLEXPRESS" '"localhost"
    

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        ' So that we only need to set the title of the application once,
        ' we use the AssemblyInfo class (defined in the AssemblyInfo.vb file)
        ' to read the AssemblyTitle attribute.
        Dim ainfo As New AssemblyInfo()

        Me.Text = ainfo.Title
        Me.mnuAbout.Text = String.Format("&About {0} ...", ainfo.Title)

        crvBasic.DisplayToolbar = True
        crvParameter.DisplayToolbar = True
        crvDynamicFormat.DisplayToolbar = True
        crvGraphDrillDown.DisplayToolbar = True


        ' Here we need to populate the combo box with the customer names found in the
        ' customers table in the northwind databse.
        Dim cnSQL As SqlConnection
        Dim cmSQL As SqlCommand
        ' Create a datareader object to read the data from the command object.
        Dim drSQL As SqlDataReader

        ' Display a status message box saying that we are attempting to connect.
        ' This only needs to be done the first time a connection is attempted.
        ' After we have determined that MSDE or SQL Server is installed, this 
        ' message no longer needs to be displayed
        Dim frmStatusMessage As New frmStatus()
        If Not HasConnected Then
            frmStatusMessage.Show("Connecting to SQL Server")
        End If

        ' Attempt to connect to SQL server or MSDE
        Dim IsConnecting As Boolean = True
        While IsConnecting
            Try
                ' Define connection string.
                ' You may need to change this for your environment.
                cnSQL = New SqlConnection(ConnectionString)
                cnSQL.Open()

                ' Instantiate Command Object to execute SQL Statements
                cmSQL = New SqlCommand()

                ' Attach the command to the connection
                cmSQL.Connection = cnSQL

                ' Set the command type to Text
                cmSQL.CommandType = CommandType.Text

                ' START: Commands are for this How-To only.
                ' Drop GetAllCustomerOrders Store Procedure if it exists.
                cmSQL.CommandText = "IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[GetAllCustomerOrders]') and OBJECTPROPERTY(id, N'IsProcedure') = 1) " & _
                                                        "DROP PROCEDURE [dbo].[GetAllCustomerOrders] "

                ' Execute the statement
                cmSQL.ExecuteNonQuery()

                ' Create GetAllCustomerOrders Stored Procedure
                cmSQL.CommandText = "CREATE PROCEDURE dbo.GetAllCustomerOrders " & _
                                        "AS " & _
                                    "SELECT CUST.CompanyName, " & _
                                        "ORD.OrderID, " & _
                                        "ORD.OrderDate, " & _
                                        "ORD.ShippedDate, " & _
                                        "PROD.ProductName, " & _
                                        "ORD_D.UnitPrice, " & _
                                        "ORD_D.Quantity " & _
                                    "FROM Customers CUST " & _
                                        "INNER JOIN Orders ORD " & _
                                        "ON CUST.CustomerID = ORD.CustomerID " & _
                                        "INNER JOIN [Order Details] ORD_D " & _
                                        "ON ORD.OrderID = ORD_D.OrderID " & _
                                        "INNER JOIN Products PROD " & _
                                        "ON ORD_D.ProductID = PROD.ProductID " & _
                                        "ORDER BY ORD.OrderDate	" & _
                                    "Return"

                ' Execute the statement
                cmSQL.ExecuteNonQuery()

                ' Drop GetCustomerOrders Store Procedure if it exists.  This How-To Only
                cmSQL.CommandText = "IF EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetCustomerOrders]') and OBJECTPROPERTY(id, N'IsProcedure') = 1) " & _
                                                        "DROP PROCEDURE [dbo].[GetCustomerOrders] "

                ' Execute the statement
                cmSQL.ExecuteNonQuery()

                cmSQL.CommandText = "CREATE PROCEDURE dbo.GetCustomerOrders " & _
                                        "@CustomerName nvarchar(50) " & _
                                        "AS " & _
                                    "SELECT ORD.OrderID, " & _
                                        "ORD.ShippedDate, " & _
                                        "ORD.OrderDate, " & _
                                        "PROD.ProductName, " & _
                                        "ORD_D.UnitPrice, " & _
                                        "ORD_D.Quantity " & _
                                    "FROM Customers CUST " & _
                                        "INNER JOIN Orders ORD " & _
                                        "ON CUST.CustomerID = ORD.CustomerID " & _
                                        "INNER JOIN [Order Details] ORD_D " & _
                                        "ON ORD.OrderID = ORD_D.OrderID " & _
                                        "INNER JOIN Products PROD " & _
                                        "ON ORD_D.ProductID = PROD.ProductID " & _
                                    "WHERE CUST.CompanyName = @CustomerName " & _
                                    "ORDER BY ORD.OrderDate	" & _
                                    "RETURN"

                ' Execute the statement
                cmSQL.ExecuteNonQuery()
                ' END: Commands for this How-To only.             

                ' Select statement to pull all the customers from
                ' the customer table in the northwind databse.
                cmSQL.CommandText = "SELECT CompanyName " & _
                                    "FROM Customers"

                ' Execute the query we defined in the command object.
                drSQL = cmSQL.ExecuteReader()

                ' Loop through the records while there is still records to 
                ' retrieve.
                Do While drSQL.Read()
                    ' Add the Customers Company Name to the combo box.
                    cbCustomers.Items.Add(drSQL("CompanyName").ToString())
                Loop

                ' Set the combo box to the first item.
                cbCustomers.SelectedIndex = 0

                IsConnecting = False
                HasConnected = True

                ' Close Connection.
                drSQL.Close()
                cnSQL.Close()

                ' Clean up.
                cnSQL.Dispose()
                cmSQL.Dispose()

            Catch Err As SqlException
                If ConnectionString = SQL_CONNECTION_STRING Then
                    ' Couldn't connect to SQL server. Now try MSDE
                    ConnectionString = MSDE_CONNECTION_STRING
                    ServerNAme = MSDE_SERVER
                    frmStatusMessage.Show("Connecting to MSDE")
                Else
                    ' Unable to connect to SQL Server or MSDE
                    frmStatusMessage.Close()
                    MsgBox("To run this sample you must have SQL Server ot MSDE with " & _
                           "the Northwind database installed.  For instructions on " & _
                           "installing MSDE, view the Readme file.", MsgBoxStyle.Critical, _
                           "SQL Server/MSDE not found")
                    ' Quit program if neither connection method was successful.
                    End

                End If
            Catch Err As Exception
                ' Report Non SQL Error to the user.
                MsgBox(Err.ToString(), MsgBoxStyle.Critical, "General Error")
            End Try
        End While
    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents mnuMain As System.Windows.Forms.MainMenu
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem2 As System.Windows.Forms.MenuItem
    Friend WithEvents mnuAbout As System.Windows.Forms.MenuItem
    Friend WithEvents mnuExit As System.Windows.Forms.MenuItem
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents tpReportBasic As System.Windows.Forms.TabPage
    Friend WithEvents crvBasic As CrystalDecisions.Windows.Forms.CrystalReportViewer
    Friend WithEvents tpParameterReport As System.Windows.Forms.TabPage
    Friend WithEvents crvParameter As CrystalDecisions.Windows.Forms.CrystalReportViewer
    Friend WithEvents lblCustomer As System.Windows.Forms.Label
    Friend WithEvents cbCustomers As System.Windows.Forms.ComboBox
    Friend WithEvents btnPreviewCustomerReport As System.Windows.Forms.Button
    Friend WithEvents tpDynamicFormatReport As System.Windows.Forms.TabPage
    Friend WithEvents tpGraphDrillDownReport As System.Windows.Forms.TabPage
    Friend WithEvents crvDynamicFormat As CrystalDecisions.Windows.Forms.CrystalReportViewer
    Friend WithEvents crvGraphDrillDown As CrystalDecisions.Windows.Forms.CrystalReportViewer
    Friend WithEvents txtUnitsToHighlight As System.Windows.Forms.TextBox
    Friend WithEvents cbHighlightColor As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents btnPreviewDrillDownReport As System.Windows.Forms.Button
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents btnPreviewBasicReport As System.Windows.Forms.Button
    Friend WithEvents btnPreviewDynamicReport As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.mnuMain = New System.Windows.Forms.MainMenu(Me.components)
        Me.MenuItem1 = New System.Windows.Forms.MenuItem
        Me.mnuExit = New System.Windows.Forms.MenuItem
        Me.MenuItem2 = New System.Windows.Forms.MenuItem
        Me.mnuAbout = New System.Windows.Forms.MenuItem
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.tpReportBasic = New System.Windows.Forms.TabPage
        Me.btnPreviewBasicReport = New System.Windows.Forms.Button
        Me.crvBasic = New CrystalDecisions.Windows.Forms.CrystalReportViewer
        Me.tpDynamicFormatReport = New System.Windows.Forms.TabPage
        Me.Label4 = New System.Windows.Forms.Label
        Me.btnPreviewDynamicReport = New System.Windows.Forms.Button
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.cbHighlightColor = New System.Windows.Forms.ComboBox
        Me.txtUnitsToHighlight = New System.Windows.Forms.TextBox
        Me.crvDynamicFormat = New CrystalDecisions.Windows.Forms.CrystalReportViewer
        Me.tpParameterReport = New System.Windows.Forms.TabPage
        Me.btnPreviewCustomerReport = New System.Windows.Forms.Button
        Me.lblCustomer = New System.Windows.Forms.Label
        Me.cbCustomers = New System.Windows.Forms.ComboBox
        Me.crvParameter = New CrystalDecisions.Windows.Forms.CrystalReportViewer
        Me.tpGraphDrillDownReport = New System.Windows.Forms.TabPage
        Me.Label3 = New System.Windows.Forms.Label
        Me.btnPreviewDrillDownReport = New System.Windows.Forms.Button
        Me.crvGraphDrillDown = New CrystalDecisions.Windows.Forms.CrystalReportViewer
        Me.TabControl1.SuspendLayout()
        Me.tpReportBasic.SuspendLayout()
        Me.tpDynamicFormatReport.SuspendLayout()
        Me.tpParameterReport.SuspendLayout()
        Me.tpGraphDrillDownReport.SuspendLayout()
        Me.SuspendLayout()
        '
        'mnuMain
        '
        Me.mnuMain.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem1, Me.MenuItem2})
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 0
        Me.MenuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuExit})
        resources.ApplyResources(Me.MenuItem1, "MenuItem1")
        '
        'mnuExit
        '
        Me.mnuExit.Index = 0
        resources.ApplyResources(Me.mnuExit, "mnuExit")
        '
        'MenuItem2
        '
        Me.MenuItem2.Index = 1
        Me.MenuItem2.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuAbout})
        resources.ApplyResources(Me.MenuItem2, "MenuItem2")
        '
        'mnuAbout
        '
        Me.mnuAbout.Index = 0
        resources.ApplyResources(Me.mnuAbout, "mnuAbout")
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.tpReportBasic)
        Me.TabControl1.Controls.Add(Me.tpDynamicFormatReport)
        Me.TabControl1.Controls.Add(Me.tpParameterReport)
        Me.TabControl1.Controls.Add(Me.tpGraphDrillDownReport)
        resources.ApplyResources(Me.TabControl1, "TabControl1")
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        '
        'tpReportBasic
        '
        Me.tpReportBasic.Controls.Add(Me.btnPreviewBasicReport)
        Me.tpReportBasic.Controls.Add(Me.crvBasic)
        resources.ApplyResources(Me.tpReportBasic, "tpReportBasic")
        Me.tpReportBasic.Name = "tpReportBasic"
        '
        'btnPreviewBasicReport
        '
        resources.ApplyResources(Me.btnPreviewBasicReport, "btnPreviewBasicReport")
        Me.btnPreviewBasicReport.Name = "btnPreviewBasicReport"
        '
        'crvBasic
        '
        Me.crvBasic.ActiveViewIndex = -1
        resources.ApplyResources(Me.crvBasic, "crvBasic")
        Me.crvBasic.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.crvBasic.Name = "crvBasic"
        Me.crvBasic.SelectionFormula = ""
        Me.crvBasic.ViewTimeSelectionFormula = ""
        '
        'tpDynamicFormatReport
        '
        Me.tpDynamicFormatReport.Controls.Add(Me.Label4)
        Me.tpDynamicFormatReport.Controls.Add(Me.btnPreviewDynamicReport)
        Me.tpDynamicFormatReport.Controls.Add(Me.Label2)
        Me.tpDynamicFormatReport.Controls.Add(Me.Label1)
        Me.tpDynamicFormatReport.Controls.Add(Me.cbHighlightColor)
        Me.tpDynamicFormatReport.Controls.Add(Me.txtUnitsToHighlight)
        Me.tpDynamicFormatReport.Controls.Add(Me.crvDynamicFormat)
        resources.ApplyResources(Me.tpDynamicFormatReport, "tpDynamicFormatReport")
        Me.tpDynamicFormatReport.Name = "tpDynamicFormatReport"
        '
        'Label4
        '
        resources.ApplyResources(Me.Label4, "Label4")
        Me.Label4.Name = "Label4"
        '
        'btnPreviewDynamicReport
        '
        resources.ApplyResources(Me.btnPreviewDynamicReport, "btnPreviewDynamicReport")
        Me.btnPreviewDynamicReport.Name = "btnPreviewDynamicReport"
        '
        'Label2
        '
        resources.ApplyResources(Me.Label2, "Label2")
        Me.Label2.Name = "Label2"
        '
        'Label1
        '
        resources.ApplyResources(Me.Label1, "Label1")
        Me.Label1.Name = "Label1"
        '
        'cbHighlightColor
        '
        resources.ApplyResources(Me.cbHighlightColor, "cbHighlightColor")
        Me.cbHighlightColor.Items.AddRange(New Object() {resources.GetString("cbHighlightColor.Items"), resources.GetString("cbHighlightColor.Items1"), resources.GetString("cbHighlightColor.Items2")})
        Me.cbHighlightColor.Name = "cbHighlightColor"
        '
        'txtUnitsToHighlight
        '
        resources.ApplyResources(Me.txtUnitsToHighlight, "txtUnitsToHighlight")
        Me.txtUnitsToHighlight.Name = "txtUnitsToHighlight"
        '
        'crvDynamicFormat
        '
        Me.crvDynamicFormat.ActiveViewIndex = -1
        resources.ApplyResources(Me.crvDynamicFormat, "crvDynamicFormat")
        Me.crvDynamicFormat.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.crvDynamicFormat.DisplayStatusBar = False
        Me.crvDynamicFormat.Name = "crvDynamicFormat"
        Me.crvDynamicFormat.SelectionFormula = ""
        Me.crvDynamicFormat.ViewTimeSelectionFormula = ""
        '
        'tpParameterReport
        '
        Me.tpParameterReport.Controls.Add(Me.btnPreviewCustomerReport)
        Me.tpParameterReport.Controls.Add(Me.lblCustomer)
        Me.tpParameterReport.Controls.Add(Me.cbCustomers)
        Me.tpParameterReport.Controls.Add(Me.crvParameter)
        resources.ApplyResources(Me.tpParameterReport, "tpParameterReport")
        Me.tpParameterReport.Name = "tpParameterReport"
        '
        'btnPreviewCustomerReport
        '
        resources.ApplyResources(Me.btnPreviewCustomerReport, "btnPreviewCustomerReport")
        Me.btnPreviewCustomerReport.Name = "btnPreviewCustomerReport"
        '
        'lblCustomer
        '
        resources.ApplyResources(Me.lblCustomer, "lblCustomer")
        Me.lblCustomer.Name = "lblCustomer"
        '
        'cbCustomers
        '
        resources.ApplyResources(Me.cbCustomers, "cbCustomers")
        Me.cbCustomers.Name = "cbCustomers"
        '
        'crvParameter
        '
        Me.crvParameter.ActiveViewIndex = -1
        resources.ApplyResources(Me.crvParameter, "crvParameter")
        Me.crvParameter.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.crvParameter.Name = "crvParameter"
        Me.crvParameter.SelectionFormula = ""
        Me.crvParameter.ViewTimeSelectionFormula = ""
        '
        'tpGraphDrillDownReport
        '
        Me.tpGraphDrillDownReport.Controls.Add(Me.Label3)
        Me.tpGraphDrillDownReport.Controls.Add(Me.btnPreviewDrillDownReport)
        Me.tpGraphDrillDownReport.Controls.Add(Me.crvGraphDrillDown)
        resources.ApplyResources(Me.tpGraphDrillDownReport, "tpGraphDrillDownReport")
        Me.tpGraphDrillDownReport.Name = "tpGraphDrillDownReport"
        '
        'Label3
        '
        resources.ApplyResources(Me.Label3, "Label3")
        Me.Label3.Name = "Label3"
        '
        'btnPreviewDrillDownReport
        '
        resources.ApplyResources(Me.btnPreviewDrillDownReport, "btnPreviewDrillDownReport")
        Me.btnPreviewDrillDownReport.Name = "btnPreviewDrillDownReport"
        '
        'crvGraphDrillDown
        '
        Me.crvGraphDrillDown.ActiveViewIndex = -1
        resources.ApplyResources(Me.crvGraphDrillDown, "crvGraphDrillDown")
        Me.crvGraphDrillDown.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.crvGraphDrillDown.DisplayStatusBar = False
        Me.crvGraphDrillDown.Name = "crvGraphDrillDown"
        Me.crvGraphDrillDown.SelectionFormula = ""
        Me.crvGraphDrillDown.ViewTimeSelectionFormula = ""
        '
        'frmMain
        '
        resources.ApplyResources(Me, "$this")
        Me.Controls.Add(Me.TabControl1)
        Me.Menu = Me.mnuMain
        Me.Name = "frmMain"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.TabControl1.ResumeLayout(False)
        Me.tpReportBasic.ResumeLayout(False)
        Me.tpDynamicFormatReport.ResumeLayout(False)
        Me.tpDynamicFormatReport.PerformLayout()
        Me.tpParameterReport.ResumeLayout(False)
        Me.tpParameterReport.PerformLayout()
        Me.tpGraphDrillDownReport.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

#Region " Standard Menu Code "
    ' <System.Diagnostics.DebuggerStepThrough()> has been added to some procedures since they are
    ' not the focus of the demo. Remove them if you wish to debug the procedures.
    ' This code simply shows the About form.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub mnuAbout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuAbout.Click
        ' Open the About form in Dialog Mode
        Dim frm As New frmAbout()
        frm.ShowDialog(Me)
        frm.Dispose()
    End Sub

    ' This code will close the form.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub mnuExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuExit.Click
        ' Close the current form
        Me.Close()
    End Sub
#End Region

    Private Sub btnPreviewBasicReport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPreviewBasicReport.Click
        ' In this event the Ten Most Expensive Products Report is loaded 
        ' and displayed in the crystal reports viewer.

        ' Objects used to set the proper database connection information
        Dim tbCurrent As CrystalDecisions.CrystalReports.Engine.Table
        Dim tliCurrent As CrystalDecisions.Shared.TableLogOnInfo

        ' Create a report document instance to hold the report
        Dim rptExpensiveProducts As New ReportDocument()

        Try
            ' Load the report
            rptExpensiveProducts.Load("..\TenMostExpensiveProducts.rpt")

            ' Set the connection information for all the tables used in the report
            ' Leave UserID and Password blank for trusted connection
            For Each tbCurrent In rptExpensiveProducts.Database.Tables
                tliCurrent = tbCurrent.LogOnInfo
                With tliCurrent.ConnectionInfo
                    .ServerName = ServerName
                    .UserID = ""
                    .Password = ""
                    .DatabaseName = "Northwind"
                End With
                tbCurrent.ApplyLogOnInfo(tliCurrent)
            Next tbCurrent

            ' Set the report source for the crystal reports 
            ' viewer to the report instance.
            crvBasic.ReportSource = rptExpensiveProducts

            ' Zoom viewer to fit to the whole page so the user can see the report
            crvBasic.Zoom(2)

        Catch Exp As LoadSaveReportException
            MsgBox("Incorrect path for loading report.", _
                    MsgBoxStyle.Critical, "Load Report Error")

        Catch Exp As Exception
            MsgBox(Exp.Message, MsgBoxStyle.Critical, "General Error")

        End Try
    End Sub

    Private Sub btnPreviewCustomerReport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPreviewCustomerReport.Click
        ' In this event the Customer Orders Report is loaded 
        ' and displayed in the crystal reports viewer.
        ' This report calls for a parameter which is pulled
        ' from the customer name combo box (cbCustomers).

        ' Objects used to set the parameters in the report
        Dim pvCollection As New CrystalDecisions.Shared.ParameterValues()
        Dim pdvCustomerName As New CrystalDecisions.Shared.ParameterDiscreteValue()

        ' Objects used to set the proper database connection information
        Dim tbCurrent As CrystalDecisions.CrystalReports.Engine.Table
        Dim tliCurrent As CrystalDecisions.Shared.TableLogOnInfo

        ' Create a report document instance to hold the report
        Dim rptCustomersOrders As New ReportDocument()

        Try
            ' Load the report
            rptCustomersOrders.Load("..\CustomerOrders.rpt")

            ' Set the connection information for all the tables used in the report
            ' Leave UserID and Password blank for trusted connection
            For Each tbCurrent In rptCustomersOrders.Database.Tables
                tliCurrent = tbCurrent.LogOnInfo
                With tliCurrent.ConnectionInfo
                    .ServerName = ServerName
                    .UserID = ""
                    .Password = ""
                    .DatabaseName = "Northwind"
                End With
                tbCurrent.ApplyLogOnInfo(tliCurrent)
            Next tbCurrent

            ' Set the discreet value to the customers name.
            pdvCustomerName.Value = cbCustomers.Text

            ' Add it to the parameter collection.
            pvCollection.Add(pdvCustomerName)

            ' Apply the current parameter values.
            rptCustomersOrders.DataDefinition.ParameterFields("@CustomerName").ApplyCurrentValues(pvCollection)

            ' Hide group tree for this report
            crvParameter.DisplayGroupTree = False

            ' Set the report source for the crystal reports viewer to the 
            ' report instance.
            crvParameter.ReportSource = rptCustomersOrders

            ' Zoom viewer to fit to the whole page so the user can see the report
            crvParameter.Zoom(2)

        Catch Exp As LoadSaveReportException
            MsgBox("Incorrect path for loading report.", _
                    MsgBoxStyle.Critical, "Load Report Error")

        Catch Exp As Exception
            MsgBox(Exp.Message, MsgBoxStyle.Critical, "General Error")

        End Try
    End Sub

    Private Sub btnPreviewDrillDownReport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPreviewDrillDownReport.Click
        ' In this event the Top 5 Products Sold Report is loaded 
        ' and displayed in the crystal reports viewer.
        ' This Report has a graph which can be used to drill down to the detail
        ' of the report.

        ' Create a report document instance to hold the report
        Dim rptDrillDown As New ReportDocument()

        ' Objects used to set the proper database connection information
        Dim tbCurrent As CrystalDecisions.CrystalReports.Engine.Table
        Dim tliCurrent As CrystalDecisions.Shared.TableLogOnInfo

        Try
            ' Load the report
            rptDrillDown.Load("..\Top5ProductsSold.rpt")

            ' Set the connection information for all the tables used in the report
            ' Leave UserID and Password blank for trusted connection
            For Each tbCurrent In rptDrillDown.Database.Tables
                tliCurrent = tbCurrent.LogOnInfo
                With tliCurrent.ConnectionInfo
                    .ServerName = ServerName
                    .UserID = ""
                    .Password = ""
                    .DatabaseName = "Northwind"
                End With
                tbCurrent.ApplyLogOnInfo(tliCurrent)
            Next tbCurrent

            ' Set the report source for the crystal reports viewer to 
            ' the report instance.
            crvGraphDrillDown.ReportSource = rptDrillDown

            ' Hide group tree for this report
            crvParameter.DisplayGroupTree = False

            ' Zoom viewer to fit to the whole page so the user can see the report
            crvGraphDrillDown.Zoom(2)

        Catch Exp As LoadSaveReportException
            MsgBox("Incorrect path for loading report.", _
                    MsgBoxStyle.Critical, "Load Report Error")

        Catch Exp As Exception
            MsgBox(Exp.Message, MsgBoxStyle.Critical, "General Error")
        End Try
    End Sub

    Private Sub btnPreviewDynamicReport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPreviewDynamicReport.Click
        ' In this event the All Customers Orders Report is loaded 
        ' and displayed in the crystal reports viewer.  On this report
        ' the user can set a unit price and a color.  These parameters
        ' are passed into the report to determine if a row is highlighted
        ' in the selected color.  During the design of the report
        ' a formula was added to the details section which controls
        ' background color.  The formula says that if the unit price is
        ' greater than the value passed in then that detail lines background
        ' color will be the color passed in else no color.

        ' This report is also a landscape report.  Inorder to display and print 
        ' a landscape report correctly a report document object must be created at 
        ' runtime and the report then needs to be assigned to
        ' it.  This is an error in Crystal and more information can be
        ' found at:  
        ' http://support.crystaldecisions/library/kbase/articles/c2011099.asp

        ' Create a report document instance to hold the report
        Dim rptAllCustomersOrders As New ReportDocument()

        ' Objects used to set the parameters in the report
        Dim pvCollection As New CrystalDecisions.Shared.ParameterValues()
        Dim pdvColor As New CrystalDecisions.Shared.ParameterDiscreteValue()
        Dim pdvUnitPrice As New CrystalDecisions.Shared.ParameterDiscreteValue()

        ' Objects used to set the proper database connection information
        Dim tbCurrent As CrystalDecisions.CrystalReports.Engine.Table
        Dim tliCurrent As CrystalDecisions.Shared.TableLogOnInfo

        ' Set the proper values for the colors
        Dim red As Integer = RGB(255, 0, 0)
        Dim green As Integer = RGB(0, 255, 0)
        Dim blue As Integer = RGB(0, 0, 255)

        If Not IsNumeric(txtUnitsToHighlight.Text) Then
            MsgBox("Please enter a number into the unit price text box.", _
                    MsgBoxStyle.Exclamation, Me.Text)
            Exit Sub
        End If

        Try
            ' Load the report
            rptAllCustomersOrders.Load("..\AllCustomersOrders.rpt")

            ' Set the connection information for all the tables used in the report
            ' Leave UserID and Password blank for trusted connection
            For Each tbCurrent In rptAllCustomersOrders.Database.Tables
                tliCurrent = tbCurrent.LogOnInfo
                With tliCurrent.ConnectionInfo
                    .ServerName = ServerName
                    .UserID = ""
                    .Password = ""
                    .DatabaseName = "Northwind"
                End With
                tbCurrent.ApplyLogOnInfo(tliCurrent)
            Next tbCurrent

            ' Set the discreet value to the selected color.
            Select Case cbHighlightColor.Text
                Case "Red"
                    pdvColor.Value = red
                Case "Green"
                    pdvColor.Value = green
                Case "Blue"
                    pdvColor.Value = blue
            End Select

            ' Set the discreet value to the Unit Price.
            pdvUnitPrice.Value = CInt(txtUnitsToHighlight.Text)

            ' Add the color value to the parameter collection.
            pvCollection.Add(pdvColor)

            ' Apply the color parameter value.
            rptAllCustomersOrders.DataDefinition.ParameterFields("ColorToHighlight").ApplyCurrentValues(pvCollection)

            ' Clear for next parameter
            pvCollection.Clear()

            ' Add the unit price value to the parameter collection.
            pvCollection.Add(pdvUnitPrice)

            ' Apply the unit price parameter value.
            rptAllCustomersOrders.DataDefinition.ParameterFields("PriceToCheck").ApplyCurrentValues(pvCollection)

            ' Show group tree for this report
            crvDynamicFormat.DisplayGroupTree = True

            ' Set the report source for the crystal reports viewer to 
            ' the report instance.
            crvDynamicFormat.ReportSource = rptAllCustomersOrders

            ' Zoom viewer to fit whole page so the user can see the report
            crvDynamicFormat.Zoom(2)

        Catch Exp As LoadSaveReportException
            MsgBox("Incorrect path for loading report.", _
                    MsgBoxStyle.Critical, "Load Report Error")

        Catch Exp As Exception
            MsgBox(Exp.Message, MsgBoxStyle.Critical, "General Error")
        End Try
    End Sub
End Class
